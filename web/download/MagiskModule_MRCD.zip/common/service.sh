#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
# More info in the main Magisk thread


## wait till boot complete
while sleep 5; do
    if [ "$(getprop sys.boot_completed)" -eq "1" ] || [ "$(getprop dev.bootcomplete)" -eq "1" ]; then break; fi
done

## handover to script on sdcard if exists
## sdcard is usually fat32 so need to use sh script.sh
if [ -r $EXTERNAL_STORAGE/MRCD/MRCD.sh ]; then
    . $EXTERNAL_STORAGE/MRCD/MRCD.sh &> $EXTERNAL_STORAGE/MRCD/MRCD_$(date +%Y-%m-%dT%T%z).log
    exit 0
fi

## if MRCD.sh is not avaiable where it should be
## shut down after 30 mins
sleep 1800
reboot -p

